import Link from "next/link";
import {
  ArrowRight,
  BarChart3,
  BookOpenCheck,
  Brain,
  CheckCircle2,
  Clock3,
  Ear,
  Gamepad2,
  HandHeart,
  Layers3,
  ShieldCheck,
  Sparkles,
  Star,
  Target,
  Users,
  Volume2,
} from "lucide-react";
import { SiteFooter, SiteHeader } from "@/components/site-chrome";
import { ShareButton } from "@/components/share-modal";
import { HeroArt } from "@/components/hero-art";
import { AchievementsPanel } from "@/components/home/achievements-panel";
import { GameGrid } from "@/components/home/game-grid";
import { GAMES, GAME_MAP, isGameSlug } from "@/lib/games";
import { loadPlatformStats } from "@/lib/platform-stats";
import { SectionHeading } from "@/components/ui";

export const dynamic = "force-dynamic";

const STEPS = [
  {
    title: "Ойынды таңда",
    text: "Бес ойынның кез келгенін аш. Әр ойын бір танымдық дағдыны дамытады.",
    icon: Gamepad2,
    tone: "#26B6B2",
    soft: "#E5F7F6",
  },
  {
    title: "Деңгейді белгіле",
    text: "Жеңіл деңгейден баста. Дайын болсаң, орташа мен күрделіге өт.",
    icon: Layers3,
    tone: "#9271E8",
    soft: "#F0E9FF",
  },
  {
    title: "Ойна да, жұлдыз жина",
    text: "Көмекті қолдан, қатені түзет. Нәтижең мен жұлдыздарың сақталады.",
    icon: Star,
    tone: "#F7B23B",
    soft: "#FFF6E6",
  },
];

const INCLUSIVE = [
  { icon: Clock3, title: "Уақыт қыспайды", text: "Таймер жоқ. Өз қарқыныңмен ойна." },
  { icon: Ear, title: "Дыбысты нұсқаулық", text: "Тапсырманы тыңдап та түсінуге болады." },
  { icon: ShieldCheck, title: "Мейірімді кері байланыс", text: "Қате — үйренудің бір бөлігі." },
  { icon: HandHeart, title: "Үлкен батырмалар", text: "Тышқанмен де, саусақпен де ыңғайлы." },
];

const SKILL_ICONS = [
  { label: "Зейін", icon: Target },
  { label: "Жад", icon: Brain },
  { label: "Логика", icon: CheckCircle2 },
  { label: "Қабылдау", icon: Sparkles },
  { label: "Пішін мен түс", icon: BarChart3 },
];

export default async function HomePage() {
  const stats = await loadPlatformStats();
  const maxGameAttempts = Math.max(1, ...Object.values(stats.perGame));

  const dateFormat = new Intl.DateTimeFormat("kk-KZ", {
    day: "numeric",
    month: "long",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Almaty",
  });

  return (
    <div className="relative">
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden="true">
        <div className="absolute -left-40 top-24 size-[28rem] rounded-full bg-skylight/70 blur-3xl" />
        <div className="absolute -right-32 top-64 size-[26rem] rounded-full bg-grapelight/70 blur-3xl" />
      </div>

      <SiteHeader />

      <main id="main">
        <section className="relative overflow-hidden" aria-labelledby="hero-title">
          <div className="mx-auto grid w-full max-w-7xl items-center gap-10 px-4 pb-10 pt-8 sm:px-6 lg:grid-cols-[1.02fr_0.98fr] lg:gap-8 lg:pb-16 lg:pt-12 lg:px-8">
            <div className="animate-rise">
              <span className="pill bg-white text-ink shadow-soft">
                <span className="grid size-2 place-items-center rounded-full bg-teal">
                  <span className="size-2 animate-pulse-ring rounded-full bg-teal" />
                </span>
                Цифрлық инклюзия · интерактивті жұмыс дәптері
              </span>

              <h1
                id="hero-title"
                className="mt-5 text-[2.15rem] font-black leading-[1.06] tracking-tight text-ink sm:text-5xl lg:text-[3.35rem]"
              >
                Таным <span className="relative inline-block text-teal-deep">әлеміне</span>
                <br />
                қош келдің!
              </h1>

              <p className="mt-4 max-w-xl text-base font-semibold leading-relaxed text-ink-soft sm:text-lg">
                Бүгін жаңа тапсырмаларды орындап, өз қабілетіңді дамыт! Бес интерактивті ойын, он бес
                деңгей және сені күтіп тұрған жұлдыздар.
              </p>

              <div className="mt-6 flex flex-wrap items-center gap-3">
                <Link href="#games" className="btn btn-primary px-6 py-3.5 text-base">
                  <Gamepad2 size={19} aria-hidden="true" />
                  Ойынды таңдау
                  <ArrowRight size={18} aria-hidden="true" />
                </Link>
                <Link href="#guide" className="btn btn-ghost px-5 py-3.5 text-base">
                  <BookOpenCheck size={19} aria-hidden="true" />
                  Қалай ойнау керек?
                </Link>
              </div>

              <div className="mt-7 flex flex-wrap gap-2">
                {SKILL_ICONS.map(({ label, icon: Icon }) => (
                  <span
                    key={label}
                    className="inline-flex items-center gap-1.5 rounded-full border border-ink/8 bg-white/80 px-3 py-1.5 text-xs font-extrabold text-ink-soft"
                  >
                    <Icon size={14} className="text-teal" aria-hidden="true" />
                    {label}
                  </span>
                ))}
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs font-extrabold text-ink-soft/90">
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 size={15} className="text-mint" aria-hidden="true" /> Тіркелу жоқ
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Volume2 size={15} className="text-grape" aria-hidden="true" /> Дыбыс қосылады
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <ShieldCheck size={15} className="text-teal" aria-hidden="true" /> Прогресс сақталады
                </span>
              </div>
            </div>

            <div className="animate-rise" style={{ animationDelay: "120ms" }}>
              <HeroArt />
            </div>
          </div>
        </section>

        <div className="mx-auto w-full max-w-7xl space-y-14 px-4 pb-4 sm:px-6 lg:space-y-20 lg:px-8">
          <AchievementsPanel />

          <section id="games" aria-labelledby="games-title" className="scroll-mt-24">
            <SectionHeading
              eyebrow="Ойындарды таңда"
              title="Бес ойын — бес танымдық бағыт"
              description="Әр ойынның үш деңгейі бар: жеңіл, орташа және күрделі. Қалағанынан бастап, көмекпен бірге орында."
              action={
                <div className="flex items-center gap-2 rounded-2xl bg-white px-4 py-3 shadow-soft">
                  <Sparkles size={18} className="text-grape" aria-hidden="true" />
                  <div className="text-xs font-extrabold leading-tight text-ink">
                    Барлығы 45 жұлдыз
                    <span className="block font-bold text-ink-soft">15 деңгей</span>
                  </div>
                </div>
              }
            />
            <div className="mt-6">
              <GameGrid />
            </div>
          </section>

          <section id="guide" aria-labelledby="guide-title" className="scroll-mt-24">
            <SectionHeading
              eyebrow="Нұсқаулық"
              title="Қалай ойнау керек?"
              description="Үш қарапайым қадам. Ережені есте сақтау қажет емес — әр экранда қысқа нұсқаулық бар."
            />
            <div className="mt-6 grid gap-4 md:grid-cols-3">
              {STEPS.map((step, index) => {
                const Icon = step.icon;
                return (
                  <div key={step.title} className="surface card-hover relative overflow-hidden p-6">
                    <span className="absolute right-5 top-4 text-5xl font-black text-ink/5">
                      {index + 1}
                    </span>
                    <span
                      className="grid size-12 place-items-center rounded-2xl"
                      style={{ backgroundColor: step.soft, color: step.tone }}
                    >
                      <Icon size={24} aria-hidden="true" />
                    </span>
                    <h3 className="mt-4 text-lg font-black text-ink">{step.title}</h3>
                    <p className="mt-1.5 text-sm font-semibold leading-relaxed text-ink-soft">{step.text}</p>
                  </div>
                );
              })}
            </div>

            <div className="mt-5 grid gap-4 lg:grid-cols-[1.35fr_1fr]">
              <div className="surface p-5 sm:p-6">
                <h3 className="flex items-center gap-2 text-base font-black text-ink">
                  <HandHeart size={20} className="text-grape" aria-hidden="true" />
                  Барлық балаға қолжетімді
                </h3>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  {INCLUSIVE.map((item) => {
                    const Icon = item.icon;
                    return (
                      <div key={item.title} className="rounded-2xl bg-canvas p-4">
                        <span className="flex items-center gap-2 text-sm font-black text-ink">
                          <Icon size={17} className="text-teal" aria-hidden="true" />
                          {item.title}
                        </span>
                        <p className="mt-1 text-xs font-semibold leading-relaxed text-ink-soft">{item.text}</p>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="relative overflow-hidden rounded-4xl border border-ink/6 bg-gradient-to-br from-grapelight via-white to-skylight p-6 shadow-soft">
                <span className="pill bg-white text-grape-deep">
                  <Users size={14} aria-hidden="true" /> Ата-ана мен мұғалімге
                </span>
                <h3 className="mt-3 text-xl font-black leading-tight text-ink">
                  Бір экранда — бір тапсырма
                </h3>
                <p className="mt-2 text-sm font-semibold leading-relaxed text-ink-soft">
                  Артық ақпарат жоқ. Әр тапсырмада қысқа нұсқаулық, «Көмек» және үлкен батырмалар бар.
                  Бала қателескенде жағымсыз дыбыс пен қызыл ескерту қолданылмайды.
                </p>
                <div className="mt-5 flex flex-wrap gap-2.5">
                  <Link href="#games" className="btn btn-grape px-5 py-3 text-sm">
                    Баламен бірге бастау
                    <ArrowRight size={16} aria-hidden="true" />
                  </Link>
                  <ShareButton label="Оқушылармен бөлісу" className="px-4 py-3 text-sm" />
                </div>
              </div>
            </div>
          </section>

          <section id="platform" aria-labelledby="platform-title" className="scroll-mt-24">
            <SectionHeading
              eyebrow="Платформа тынысы"
              title="Таным әлемінің статистикасы"
              description="Барлық оқушылардың ойын нәтижелері серверде жинақталып, осы панельде көрсетіледі."
            />
            <div className="mt-6 grid gap-4 lg:grid-cols-[1.1fr_1fr]">
              <div className="surface p-5 sm:p-6">
                <div className="grid gap-3 sm:grid-cols-3">
                  {[
                    { label: "Оқушы", value: stats.players, icon: Users, tone: "#26B6B2", soft: "#E5F7F6" },
                    { label: "Орындалған ойын", value: stats.attempts, icon: Gamepad2, tone: "#9271E8", soft: "#F0E9FF" },
                    { label: "Жиналған жұлдыз", value: stats.stars, icon: Star, tone: "#C98A11", soft: "#FFF6E6" },
                  ].map((item) => {
                    const Icon = item.icon;
                    return (
                      <div key={item.label} className="rounded-2xl bg-canvas p-4">
                        <span
                          className="grid size-9 place-items-center rounded-xl"
                          style={{ backgroundColor: item.soft, color: item.tone }}
                        >
                          <Icon size={18} aria-hidden="true" />
                        </span>
                        <p className="mt-2 text-2xl font-black leading-tight text-ink">{item.value}</p>
                        <p className="text-[11px] font-extrabold uppercase tracking-wide text-ink-soft/80">
                          {item.label}
                        </p>
                      </div>
                    );
                  })}
                </div>

                <div className="mt-5 space-y-2.5">
                  {GAMES.map((game) => {
                    const attempts = stats.perGame[game.slug] ?? 0;
                    return (
                      <div key={game.slug} className="flex items-center gap-3">
                        <span className="w-32 shrink-0 truncate text-xs font-extrabold text-ink sm:w-44">
                          {game.title}
                        </span>
                        <span className="h-2.5 flex-1 overflow-hidden rounded-full bg-ink/8">
                          <span
                            className="block h-full rounded-full transition-all duration-700"
                            style={{
                              width: `${Math.max(attempts > 0 ? 8 : 0, (attempts / maxGameAttempts) * 100)}%`,
                              backgroundColor: game.accent,
                            }}
                          />
                        </span>
                        <span className="w-8 text-right text-xs font-black text-ink-soft">{attempts}</span>
                      </div>
                    );
                  })}
                </div>
                {stats.attempts === 0 ? (
                  <p className="mt-4 rounded-2xl bg-skylight px-4 py-3 text-xs font-bold text-ink">
                    Әзірге нәтиже жоқ. Алғашқы ойынды орындап, осы панельді өз нәтижеңмен толықтыр!
                  </p>
                ) : null}
              </div>

              <div className="surface p-5 sm:p-6">
                <h3 className="flex items-center gap-2 text-base font-black text-ink">
                  <BarChart3 size={19} className="text-teal" aria-hidden="true" />
                  Соңғы нәтижелер
                </h3>
                <ul className="mt-4 space-y-2.5">
                  {stats.recent.length === 0 ? (
                    <li className="rounded-2xl bg-canvas px-4 py-6 text-center text-sm font-semibold text-ink-soft">
                      Мұнда соңғы ойын нәтижелері пайда болады.
                    </li>
                  ) : (
                    stats.recent.map((row) => {
                      const meta = isGameSlug(row.gameSlug) ? GAME_MAP[row.gameSlug] : null;
                      const levelTitle = ["Жеңіл", "Орташа", "Күрделі"][row.level - 1] ?? "Деңгей";
                      return (
                        <li
                          key={row.id}
                          className="flex items-center gap-3 rounded-2xl bg-canvas px-3.5 py-3"
                        >
                          <span
                            className="grid size-9 shrink-0 place-items-center rounded-xl text-xs font-black"
                            style={{
                              backgroundColor: meta?.soft ?? "#E5F7F6",
                              color: meta?.deep ?? "#172C53",
                            }}
                          >
                            {row.stars}★
                          </span>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-extrabold text-ink">
                              {meta?.title ?? "Ойын"} · {levelTitle}
                            </p>
                            <p className="truncate text-[11px] font-semibold text-ink-soft">
                              {row.playerName} · {dateFormat.format(new Date(row.createdAt))}
                            </p>
                          </div>
                        </li>
                      );
                    })
                  )}
                </ul>
              </div>
            </div>
          </section>
        </div>
      </main>

      <SiteFooter />
    </div>
  );
}
