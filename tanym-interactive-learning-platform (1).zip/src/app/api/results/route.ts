import { db, hasDatabase } from "@/db";
import { gameResults } from "@/db/schema";
import { isGameSlug } from "@/lib/games";

export const dynamic = "force-dynamic";

function intInRange(value: unknown, min: number, max: number, fallback = 0): number {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, Math.round(parsed)));
}

function cleanText(value: unknown, fallback: string, maxLength = 80): string {
  if (typeof value !== "string") return fallback;
  const trimmed = value.trim();
  if (!trimmed) return fallback;
  return trimmed.slice(0, maxLength);
}

export async function POST(request: Request) {
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== "object") {
      return Response.json({ ok: false, error: "Деректер жеткіліксіз" }, { status: 400 });
    }
    const payload = body as Record<string, unknown>;
    const gameSlug = cleanText(payload.gameSlug, "", 24);
    if (!isGameSlug(gameSlug)) {
      return Response.json({ ok: false, error: "Ойын табылмады" }, { status: 400 });
    }

    if (!hasDatabase) {
      return Response.json({ ok: true, id: null });
    }

    const [saved] = await db
      .insert(gameResults)
      .values({
        clientId: cleanText(payload.clientId, "tanym-anonymous", 64),
        playerName: cleanText(payload.playerName, "Оқушы", 40),
        gameSlug,
        level: intInRange(payload.level, 1, 3, 1),
        stars: intInRange(payload.stars, 0, 3),
        correct: intInRange(payload.correct, 0, 500),
        wrong: intInRange(payload.wrong, 0, 500),
        total: intInRange(payload.total, 0, 500),
        helpUsed: intInRange(payload.helpUsed, 0, 100),
        durationMs: intInRange(payload.durationMs, 0, 3_600_000),
      })
      .returning({ id: gameResults.id });

    return Response.json({ ok: true, id: saved?.id ?? null });
  } catch {
    return Response.json({ ok: false, error: "Сақтау мүмкін болмады" }, { status: 500 });
  }
}
