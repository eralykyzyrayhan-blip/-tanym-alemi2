"use client";

import { useEffect, useMemo, useState } from "react";
import QRCode from "qrcode";
import {
  Check,
  Copy,
  Download,
  ExternalLink,
  Maximize2,
  MessageCircle,
  Minimize2,
  QrCode,
  Send,
  Share2,
  X,
} from "lucide-react";
import { GAMES, type GameSlug } from "@/lib/games";
import { cx } from "@/components/ui";

type ShareTarget = {
  id: "home" | GameSlug;
  label: string;
  subtitle: string;
  path: string;
};

const SHARE_TARGETS: ShareTarget[] = [
  {
    id: "home",
    label: "Басты бет",
    subtitle: "Барлық 5 ойын",
    path: "/",
  },
  ...GAMES.map((game) => ({
    id: game.slug,
    label: game.title,
    subtitle: game.direction,
    path: `/oiyn/${game.slug}`,
  })),
];

function copyTextFallback(text: string): boolean {
  if (typeof document === "undefined") return false;
  try {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    textarea.style.pointerEvents = "none";
    document.body.appendChild(textarea);
    textarea.select();
    const succeeded = document.execCommand("copy");
    document.body.removeChild(textarea);
    return succeeded;
  } catch {
    return false;
  }
}

async function copyToClipboard(text: string): Promise<boolean> {
  if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      return copyTextFallback(text);
    }
  }
  return copyTextFallback(text);
}

export function ShareButton({
  initialTarget = "home",
  compact = false,
  label = "Бөлісу",
  variant = "ghost",
  className,
}: {
  initialTarget?: "home" | GameSlug;
  compact?: boolean;
  label?: string;
  variant?: "ghost" | "grape" | "primary";
  className?: string;
}) {
  const [open, setOpen] = useState(false);

  const variantClass =
    variant === "grape" ? "btn-grape" : variant === "primary" ? "btn-primary" : "btn-ghost";

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Оқушылармен сілтеме бөлісу"
        title="Оқушылармен сілтеме бөлісу"
        className={cx(
          "btn",
          variantClass,
          compact ? "size-11 min-h-11 rounded-2xl px-0 sm:size-12 sm:min-h-12" : "px-4 py-2.5 text-sm",
          className,
        )}
      >
        <Share2 size={17} aria-hidden="true" />
        {compact ? <span className="sr-only">{label}</span> : <span>{label}</span>}
      </button>

      {open ? (
        <ShareDialog initialTarget={initialTarget} onClose={() => setOpen(false)} />
      ) : null}
    </>
  );
}

function ShareDialog({
  initialTarget,
  onClose,
}: {
  initialTarget: "home" | GameSlug;
  onClose: () => void;
}) {
  const [selectedId, setSelectedId] = useState<"home" | GameSlug>(initialTarget);
  const [origin, setOrigin] = useState("");
  const [qrDataUrl, setQrDataUrl] = useState<string>("");
  const [copiedKind, setCopiedKind] = useState<"url" | "invite" | null>(null);
  const [enlargedQr, setEnlargedQr] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      setOrigin(window.location.origin);
    }
  }, []);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        if (enlargedQr) {
          setEnlargedQr(false);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [enlargedQr, onClose]);

  const target = useMemo(
    () => SHARE_TARGETS.find((item) => item.id === selectedId) ?? SHARE_TARGETS[0],
    [selectedId],
  );

  const shareUrl = origin ? `${origin}${target.path}` : target.path;

  const inviteText = useMemo(() => {
    if (target.id === "home") {
      return `TANЫM — Таным әлеміне қош келдің! Бес интерактивті ойынды орындап, өз жұлдыздарыңды жина (тіркелу қажет емес):\n${shareUrl}`;
    }
    return `TANЫM — Таным әлемі! «${target.label}» ойынын ашып, тапсырмаларды орындап көр (тіркелу қажет емес):\n${shareUrl}`;
  }, [shareUrl, target]);

  useEffect(() => {
    if (!origin) return;
    let active = true;
    QRCode.toDataURL(shareUrl, {
      width: 512,
      margin: 2,
      color: {
        dark: "#172C53",
        light: "#FFFFFF",
      },
    })
      .then((dataUrl) => {
        if (active) setQrDataUrl(dataUrl);
      })
      .catch(() => {
        if (active) setQrDataUrl("");
      });
    return () => {
      active = false;
    };
  }, [origin, shareUrl]);

  const handleCopy = async (kind: "url" | "invite", value: string) => {
    const ok = await copyToClipboard(value);
    if (ok) {
      setCopiedKind(kind);
      window.setTimeout(() => {
        setCopiedKind((current) => (current === kind ? null : current));
      }, 2400);
    }
  };

  const handleNativeOrChatShare = async () => {
    if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
      try {
        await navigator.share({
          title: `TANЫM — ${target.label}`,
          text:
            target.id === "home"
              ? "TANЫM — Таным әлеміне қош келдің! Тапсырмаларды орындап, жұлдыз жина!"
              : `TANЫM — «${target.label}» ойынын орындап көр!`,
          url: shareUrl,
        });
        return;
      } catch {
        /* пайдаланушы жапса, елемеу */
      }
    }
    const chatUrl = `https://wa.me/?text=${encodeURIComponent(inviteText)}`;
    window.open(chatUrl, "_blank", "noopener,noreferrer");
  };

  const telegramHref = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(
    target.id === "home"
      ? "TANЫM — Таным әлемі! Интерактивті ойындарды орындап, жұлдыз жина (тіркелусіз)"
      : `TANЫM — «${target.label}» интерактивті ойыны (${target.subtitle})`,
  )}`;

  const whatsappHref = `https://wa.me/?text=${encodeURIComponent(inviteText)}`;

  return (
    <div
      className="fixed inset-0 z-100 flex items-center justify-center bg-ink/50 p-3 backdrop-blur-sm sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="share-dialog-title"
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="relative max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-4xl border border-ink/8 bg-white p-5 shadow-lift animate-pop sm:p-7">
        <div className="flex items-start justify-between gap-3">
          <div>
            <span className="pill bg-grape/12 text-grape-deep">
              <Share2 size={14} aria-hidden="true" />
              Сыныппен бөлісу
            </span>
            <h2 id="share-dialog-title" className="mt-2 text-2xl font-black tracking-tight text-ink">
              Оқушыларға сілтеме жіберу
            </h2>
            <p className="mt-1 text-xs font-semibold text-ink-soft sm:text-sm">
              Басты бетті немесе нақты бір ойынды таңдап, сілтемені не камера кодын оқушыларға жібер.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Терезені жабу"
            className="btn btn-ghost size-10 min-h-10 shrink-0 rounded-2xl px-0"
          >
            <X size={19} aria-hidden="true" />
          </button>
        </div>

        <div className="mt-5">
          <p className="text-[11px] font-black uppercase tracking-wide text-ink-soft/80">
            Жіберілетін бетті таңда
          </p>
          <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
            {SHARE_TARGETS.map((item) => {
              const active = item.id === selectedId;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setSelectedId(item.id);
                    setCopiedKind(null);
                  }}
                  aria-pressed={active}
                  className={cx(
                    "rounded-2xl border-2 px-3 py-2.5 text-left transition",
                    active
                      ? "border-teal bg-skylight text-ink"
                      : "border-ink/8 bg-canvas text-ink-soft hover:border-teal/40 hover:text-ink",
                  )}
                >
                  <p className="truncate text-xs font-black text-ink">{item.label}</p>
                  <p className="truncate text-[11px] font-semibold text-ink-soft">{item.subtitle}</p>
                </button>
              );
            })}
          </div>
        </div>

        {enlargedQr && qrDataUrl ? (
          <div className="mt-5 flex flex-col items-center rounded-3xl bg-skylight p-6 text-center">
            <p className="text-base font-black text-ink">TANЫM — {target.label}</p>
            <p className="mt-0.5 text-xs font-semibold text-ink-soft">
              Телефон немесе планшет камерасын осы кодқа бағытта
            </p>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={qrDataUrl}
              alt={`${target.label} бетіне өту коды`}
              className="mt-4 size-64 rounded-3xl bg-white p-3 shadow-card sm:size-72"
            />
            <p className="mt-3 max-w-full break-all rounded-xl bg-white px-3.5 py-2 text-xs font-extrabold text-ink">
              {shareUrl}
            </p>
            <button
              type="button"
              onClick={() => setEnlargedQr(false)}
              className="btn btn-ghost mt-4 px-5 py-2.5 text-sm"
            >
              <Minimize2 size={16} aria-hidden="true" />
              Кішірейту
            </button>
          </div>
        ) : (
          <div className="mt-5 grid gap-4 sm:grid-cols-[1.35fr_0.85fr]">
            <div className="space-y-3">
              <div className="rounded-3xl bg-canvas p-4">
                <label
                  htmlFor="tanym-share-url"
                  className="text-[11px] font-black uppercase tracking-wide text-ink-soft/80"
                >
                  Тікелей сілтеме
                </label>
                <div className="mt-2 flex items-center gap-2">
                  <input
                    id="tanym-share-url"
                    type="text"
                    readOnly
                    value={shareUrl}
                    onFocus={(event) => event.currentTarget.select()}
                    className="h-11 min-w-0 flex-1 rounded-2xl border border-ink/12 bg-white px-3.5 text-xs font-bold text-ink outline-none focus:border-teal"
                  />
                  <a
                    href={shareUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Жаңа бетте ашу"
                    title="Жаңа бетте ашу"
                    className="btn btn-ghost size-11 min-h-11 shrink-0 rounded-2xl px-0"
                  >
                    <ExternalLink size={17} aria-hidden="true" />
                  </a>
                </div>

                <button
                  type="button"
                  onClick={() => void handleCopy("url", shareUrl)}
                  className="btn btn-primary mt-3 w-full px-4 py-3 text-sm"
                >
                  {copiedKind === "url" ? (
                    <>
                      <Check size={17} aria-hidden="true" />
                      Сілтеме көшірілді!
                    </>
                  ) : (
                    <>
                      <Copy size={17} aria-hidden="true" />
                      Сілтемені көшіру
                    </>
                  )}
                </button>
              </div>

              <div className="rounded-3xl bg-grapelight/70 p-4">
                <p className="text-[11px] font-black uppercase tracking-wide text-grape-deep">
                  Сынып чатына дайын шақыру
                </p>
                <p className="mt-1.5 line-clamp-3 text-xs font-semibold leading-relaxed text-ink-soft">
                  {inviteText}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => void handleCopy("invite", inviteText)}
                    className="btn btn-ghost min-h-10 flex-1 px-3.5 py-2 text-xs"
                  >
                    {copiedKind === "invite" ? (
                      <>
                        <Check size={15} className="text-mint" aria-hidden="true" />
                        Мәтін көшірілді!
                      </>
                    ) : (
                      <>
                        <Copy size={15} aria-hidden="true" />
                        Мәтінді көшіру
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleNativeOrChatShare()}
                    className="btn btn-grape min-h-10 flex-1 px-3.5 py-2 text-xs"
                  >
                    <Share2 size={15} aria-hidden="true" />
                    Жіберу
                  </button>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <a
                    href={whatsappHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-ghost min-h-10 px-3 py-2 text-xs"
                  >
                    <MessageCircle size={15} className="text-mint" aria-hidden="true" />
                    Чатқа жіберу
                  </a>
                  <a
                    href={telegramHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-ghost min-h-10 px-3 py-2 text-xs"
                  >
                    <Send size={15} className="text-teal" aria-hidden="true" />
                    Арнаға жіберу
                  </a>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center justify-between rounded-3xl border border-ink/8 bg-skylight/75 p-4 text-center">
              <div className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wide text-ink">
                <QrCode size={14} className="text-teal-deep" aria-hidden="true" />
                Тақтаға арналған код
              </div>
              {qrDataUrl ? (
                /* eslint-disable-next-line @next/next/no-img-element */
                <img
                  src={qrDataUrl}
                  alt={`${target.label} бетіне өту коды`}
                  className="my-3 size-38 rounded-2xl bg-white p-2 shadow-soft"
                />
              ) : (
                <div className="my-3 grid size-38 place-items-center rounded-2xl bg-white text-xs font-bold text-ink-soft">
                  Дайындалуда…
                </div>
              )}
              <div className="flex w-full flex-col gap-1.5">
                <button
                  type="button"
                  onClick={() => setEnlargedQr(true)}
                  disabled={!qrDataUrl}
                  className="btn btn-ghost min-h-10 w-full px-3 py-2 text-xs"
                >
                  <Maximize2 size={14} aria-hidden="true" />
                  Тақтаға үлкейту
                </button>
                {qrDataUrl ? (
                  <a
                    href={qrDataUrl}
                    download={`tanym-${target.id}.png`}
                    className="btn btn-ghost min-h-10 w-full px-3 py-2 text-xs"
                  >
                    <Download size={14} aria-hidden="true" />
                    Кодты жүктеу
                  </a>
                ) : null}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
